from selenium import webdriver
from whatsapp_api import WhatsApp
from time import sleep
from chatterbot.trainers import ListTrainer
from chatterbot import ChatBot
import aiml
import os
from googletrans import Translator as tr
from translate import Translator as trans

## class = "P6z4j" classe do numero de mensagens do elemento
## class = "X7YrQ" elementos de mensagens
# class = "_1H6CJ" todos os elementos juntos
# X7YrQ
# 'C:/Users/leohe/Desktop/bot wpp/bot/python-aiml'
wpp = WhatsApp()
os.chdir('C:/Users/leohe/Desktop/bot wpp/bot/python-aiml') # diretório que contém os arquivos da AIML standard
ai = aiml.Kernel() # inicialização
ai.learn('std-startup.xml') # lê o arquivo principal da AIML e faz referências aos outros
ai.respond('load aiml b') # faz com que os outros arquivos da AIML sejam carregados

def resposta_bot(frase):
    trs = tr()
    frase = trs.translate(frase, dest='en') #traduz o que foi dito pra Ingles
    print("INGLES: ", frase.text)
    tr_resp = trans(to_lang='pt-br')
    resp = tr_resp.translate(ai.respond(frase.text)) # traduz a resposta para portugues
    return resp

input("Apos escanear o QR code, precione enter para dar continuidade")

valida_contact = False
##contatos = ['BiaBot', 'LeonardoBot', 'AnaBot', "CarlosBot"]
##noti = wpp.driver.find_element_by_class_name("P6z4j")
while not valida_contact:
    name = input("Digite o nome do contato: ")
    try:
            wpp.search_contact(name)
    except:
        print("Nao foi possivel achar o contato")
        continue
    valida_contact = True
last_verify = ''

resp = ''
while True:
    try:
        last_message = wpp.get_last_message()
    except:
        last_message = resp 
    print(last_message,"-    ultima mensagem")

    if last_message != resp:

        print("Entrei no if do resp")
        resposta = resposta_bot(last_message)
        wpp.send_message(resposta) 
        print(resposta,"resposta")
        resp = resposta


        ##else:
         ##   wpp.send_message("Ainda não sei responder isso.")
         ##   resp = 'Ainda não sei responder isso.'
        ##else:
            

            ##wpp.send_message("Desculpa :(. Não sei responder isso ainda.")


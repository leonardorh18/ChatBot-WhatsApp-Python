Explore options of using various NLP services e.g TextBlob to translate to and from non english to english language

Provide as both pre and post processes

Factory Pattern
    TextBlob        -> Library
    Google          -> External Service


Also provide translate extension grammar

Can you say that again in spanish
How do you say hello in spanish
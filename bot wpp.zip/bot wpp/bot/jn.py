import json
resposta = "oi"
x = {"string": resposta}
y = json.dumps(x)
print(y)